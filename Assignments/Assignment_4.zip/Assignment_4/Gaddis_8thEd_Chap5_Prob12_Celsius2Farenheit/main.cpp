/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 30, 2018, 7:05 PM
 * Purpose: Celsius to Fahrenheit Table
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <cmath>     //Math Library
#include <iomanip>   //Format Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare and initialize variables
    float f; //Fahrenheit
    int   c; //Celsius
    
    //Map inputs to outputs or process the data
    cout<<"This program creates a table that will convert Celsius to Fahrenheit.\n"<<endl;
    cout<<"Celsius   | Fahrenheit"<<endl;
    cout<<"-------------------------"<<endl;
    
    //Output data
    for (c==0;c<=20;c+=1)
    {
        f=(9/5)*c+32;   //Celsius to Fahrenheit conversion
        cout<<c<<" Celsius = "<<f<<" Fahrenheit"<<endl;
    }
    
    //Exit stage right!
    return 0;
}

