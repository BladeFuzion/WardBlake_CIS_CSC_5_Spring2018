/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 31, 2018, 1:40 PM
 * Purpose:  Distance Traveled
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare and initialize variables
    float Distnce=0;      //Distance Traveled
    int Speed,Time,HourIn;//Speed and Time
    
    //Input data
    cout<<"This program calculates distance traveled for each hour."<<endl;
    cout<<"Please input the speed of the vehicle in MPH:"<<endl;
    cin>>Speed;
    cout<<"Please input hours traveled"<<endl;
    cin>>HourIn;
    
    //Map inputs to outputs or process the data
     for (Time==HourIn;Time<=HourIn;Time+=1)
    {
        Distnce=Speed*Time;//Calories Burned per minute
        cout<<"At "<<Time<<" hours you drove "<<Distnce<<" Miles."<<endl;
    }
    
    //Exit stage right!
    return 0;
}

