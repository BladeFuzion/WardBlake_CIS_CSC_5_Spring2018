/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on April 3, 2017, 9:30 PM
 * Purpose:  Menu for Assignment 4
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <cstdlib>   //Random Number Generator
#include <ctime>     //Time library to seed the random number generator
#include <iomanip>   //Formatting
#include <cmath>     //Math Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants
const float GRAVITY=6.673e-8f;//cm^3/g/sec^2
const float CMMTRS=0.01f;//Centimeters to Meters
const float MTRSFT=3.281f;//Meters to feet
const float LBSLUG=32.174f;//Pounds per Slug

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    char choice;
    
    //Show menu and Loop
    do{
        //Display Menu
        cout<<"Type 0 to exit"<<endl;
        cout<<"Type 1 for Gaddis_8thEd_Chap5_Prob1_SumofNumbers"<<endl;
        cout<<"Type 2 for Gaddis_8thEd_Chap5_Prob2_ASCICode"<<endl;
        cout<<"Type 3 for Gaddis_8thEd_Chap5_Prob4_CaloriesBurned"<<endl;
        cout<<"Type 4 for Gaddis_8thEd_Chap5_Prob7_PenniesForPay"<<endl;
        cout<<"Type 5 for Gaddis_8thEd_Chap5_Prob8_MathTutor"<<endl;
        cout<<"Type 6 for Gaddis_8thEd_Chap5_Prob12_Celsius2Farenheit"<<endl;
        cout<<"Type 7 for Gaddis_8thEd_Chap5Prob6_Distance"<<endl;
        cout<<"Type 8 for Savitch_9thEd_Chap4_PracProb3_StockPurchase"<<endl;
        cout<<"Type 9 for Savitch_9thEd_Chap4_ProgProj_Prob2_ClothSizes"<<endl;
        
        //Input the choice
        cin>>choice;
        
        //Place solutions to problems in switch statement
        switch(choice){
            case '1':{
            //Declare and initialize variables
    //Make sure 0<n<50
    int n;
    int sum = 0;
    
    //Input data
    cout<<"This program retrieves the sum of all integers from ";
    cout<<"1 to the number entered."<<endl;
    cout<<"Please input a number from 1 to 50"<<endl;
    cin>>n;
    
    //Map inputs to outputs or process the data
    if (!(n>=1&&n<=50)){
        cout<<"You failed to input a number between 1 and 50"<<endl;
        return 1;
    }
    for (int i=1; i<=n; i++){
        sum+=i;
    }
    
    //Output the transformed data
    cout<<"The computed sum of 1 to "<<n<<" = "<<sum<<endl;
        
                break;
            }
            case '2':{
            //Map inputs to outputs or process the data
    for (int i=0;i<=127;i++){
        cout<<static_cast<char>(i);
        if (i%16==15)cout<<endl;   //Every 16 symbols, end line
    }    
                break;
            }
            case '3':{
            //Declare and initialize variables
    float CalBrn=3.9; //Calories burned per minute
    int min,Brn = 0;   //Minutes of exercise and Calories burned
    
    //Map inputs to outputs or process the data
    cout<<"This program calculates the amount of calories burned every 5 ";
    cout<<"minutes for a total of 30 minutes."<<endl;
    cout<<"-----------------------------------------------------"<<endl;
    
    //Loop calculations and output transformed data
    for (min=5;min<=30;min+=5)
    {
        Brn=CalBrn*min;   //Calories Burned per minute
        cout<<"At "<<min<<" minutes you burned "<<Brn<<" Calories."<<endl;
    }    
                break;
            }
            case '4':{
            //Declare Variables
    unsigned int totPay,pyPrDay;//Pennies per pay
    char numDays=31;            //Number of days in a month
    
    //Initial Variables
    pyPrDay;        //One penny on the first day
    totPay=pyPrDay;//Total amount
    
    //Map/Process Inputs to Outputs
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Day        Pay         Total"<<endl;
    for(int day=1;day<=numDays;day++){
        cout<<setw(2)<<day
                <<setw(12)<<pyPrDay/100.0f
                <<setw(14)<<totPay/100.0f<<endl;
        pyPrDay*=2;
        totPay+=pyPrDay;
    }
        
                break;
            }
            case '5':{
            //Initialize the random number generator with time
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare and Initialize variables
    char choice;
    short op1,op2,sum1,sum2;
    char ch;
    
    //Show menu and loop
    do{
        //Display Menu
        cout<<"Type 0 to exit"<<endl;
        cout<<"Type 1 for addition"<<endl;
        cout<<"Type 2 for subtraction"<<endl;
        cout<<"Type 3 for multiplication"<<endl;
        cout<<"Type 4 for division"<<endl;
        
        //Input choice
        cin>>choice;
        
        //Place solutions to problems in switch statement
        switch (choice){
            case '1':{
                //Declare and Initialize Variables
                short op1, op2, sum1, sum2;
                char ch;
                
                //Input data
                op1=rand()%90+10;//[10-99]
                op2=rand()%90+10;//[10-99]

                //Map inputs to outputs or process the data
                sum2 = op1+op2;

                //Output the transformed data
                cout<<"This program will add two numbers and pause for you to solve.",
                cout<<" Press ENTER to begin. "<<endl;        
                cin.get(ch);
                cout<<op1<<" + "<<op2<<" = "<<endl;
                cout<<"Please enter the answer."<<endl;
                cin>>sum1;
                if (sum1 == sum2) cout<<"You are correct, Congratulations!"<<endl;
                if (sum1>sum2&&sum1<sum2) cout<<"Sorry, the correct answer is "<<sum2<<endl;
                break;
            }
            case '2':{
                //Declare and Initialize Variables
                short op1, op2, dif1, dif2;
                char ch;
                
                //Input data
                op1=rand()%90+10;//[10-99]
                op2=rand()%90+10;//[10-99]

                //Map inputs to outputs or process the data
                dif2 = op1-op2;

                //Output the transformed data
                cout<<"This program will subtract two numbers and pause for you to solve.",
                cout<<" Press ENTER to begin. "<<endl;        
                cin.get(ch);
                cout<<op1<<" - "<<op2<<" = "<<endl;
                cout<<"Please enter the answer."<<endl;
                cin>>dif1;
                if (dif1 == dif2) cout<<"You are correct, Congratulations!"<<endl;
                if (dif1>dif2&&dif1<dif2) cout<<"Sorry, the correct answer is "<<dif2<<endl;
                break;
            }
            case '3':{
                //Declare and Initialize Variables
                short op1, op2, prod1, prod2;
                char ch;
                
                //Input data
                op1=rand()%90+10;//[10-99]
                op2=rand()%90+10;//[10-99]

                //Map inputs to outputs or process the data
                prod2 = op1*op2;

                //Output the transformed data
                cout<<"This program will multiply two numbers and pause for you to solve.",
                cout<<" Press ENTER to begin. "<<endl;        
                cin.get(ch);
                cout<<op1<<" * "<<op2<<" = "<<endl;
                cout<<"Please enter the answer."<<endl;
                cin>>prod1;
                if (prod1 == prod2) cout<<"You are correct, Congratulations!"<<endl;
                if (prod1>prod2&&prod1<prod2) cout<<"Sorry, the correct answer is "<<prod2<<endl;
                break;
                
            }
            case '4':{
                //Declare and Initialize Variables
                short op1, op2, quot1, quot2;
                char ch;
                
                //Input data
                op1=rand()%90+10;//[10-99]
                op2=rand()%90+10;//[10-99]

                //Map inputs to outputs or process the data
                quot2 = op1/op2;

                //Output the transformed data
                cout<<"This program will divide two numbers and pause for you to solve.",
                cout<<" Press ENTER to begin. "<<endl;        
                cin.get(ch);
                cout<<op1<<" / "<<op2<<" = "<<endl;
                cout<<"Please enter the answer."<<endl;
                cin>>quot1;
                if (quot1 == quot2) cout<<"You are correct, Congratulations!"<<endl;
                if (quot1>quot2&&quot1<quot2) cout<<"Sorry, the correct answer is "<<quot2<<endl;
                break;
            }
            default :{
                cout<<"Exit the program"<<endl;
            }
        }
        
    }while (choice>='1'&&choice<='4');
      
                break;
            }
            case '6':{
        //Declare and initialize variables
    float f; //Fahrenheit
    int   c; //Celsius
    
    //Map inputs to outputs or process the data
    cout<<"This program creates a table that will convert Celsius to Fahrenheit.\n"<<endl;
    cout<<"Celsius   | Fahrenheit"<<endl;
    cout<<"-------------------------"<<endl;
    
    //Output data
    for (c==0;c<=20;c+=1)
    {
        f=(9/5)*c+32;   //Celsius to Fahrenheit conversion
        cout<<c<<" Celsius = "<<f<<" Fahrenheit"<<endl;
    }
                break;
            }
            case '7':{
            //Declare and initialize variables
    float Distnce=0;      //Distance Traveled
    int Speed,Time,HourIn;//Speed and Time
    
    //Input data
    cout<<"This program calculates distance traveled for each hour."<<endl;
    cout<<"Please input the speed of the vehicle in MPH:"<<endl;
    cin>>Speed;
    cout<<"Please input hours traveled"<<endl;
    cin>>HourIn;
    
    //Map inputs to outputs or process the data
     for (Time==HourIn;Time<=HourIn;Time+=1)
    {
        Distnce=Speed*Time;//Calories Burned per minute
        cout<<"At "<<Time<<" hours you drove "<<Distnce<<" Miles."<<endl;
    }
        
                break;
            }
            case '8':{
            //Initialize the random seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    int dolStk, numStk, denStk;//Stock price $ num/den
    int numShrs;//Number of Shares
    float valStks;//Value of the stocks in $'s
    char again;//Continue or not

    //Initial Variables
    denStk=8;
    
    //Map/Process Inputs to Outputs
    do{
        //Randomly choose the stock price
        dolStk=rand()%1000;//[0-999]
        numStk=rand()%8;//[0-7]/8
        numShrs=rand()%90+10;//[10-99]
        
        //Calculate the stock value
        valStks=numShrs*(dolStk+static_cast<float>(numStk)/denStk);

        //Display Outputs
        cout<<fixed<<setprecision(2)<<showpoint;
        cout<<"The Number of shares of stock = "<<numShrs<<endl;
        cout<<"The value of the stock/share = $"
            <<dolStk<<" "<<numStk<<"/"<<denStk<<endl;
        cout<<"The total value of the stock = $"<<valStks<<endl;
        
        //Prompt user to see if they want to continue
        cout<<endl<<"Would you like to continue Y/N"<<endl;
        cin>>again;
    }while(again=='Y'||again=='y');
        
                break;
            }
            case '9':{
            //Declare Variables
    float jacket,hat,waist;
    int age;
    short height,weight;
    char repeat;
    
    //Initial Variables
    do{
        cout<<"Input your height in inches"<<endl;
        cin>>height;
        cout<<"Input your weight in pounds"<<endl;
        cin>>weight;
        cout<<"Input your age in years"<<endl;
        cin>>age;
        
        //Map/Process Inputs to Outputs
        hat=(weight/height)*2.9;
        jacket=static_cast<float>(height*weight)/288+(0.125)*((age-30)/10);
        waist=weight/5.7+(0.1)*((age-28)/2);
        
        //Display Outputs
        cout<<fixed<<setprecision(2);
        cout<<"Your hat size is "<<hat<<endl;
        cout<<"Your jacket size is "<<jacket<<" inches"<<endl;
        cout<<"Your waist size is "<<waist<<" inches"<<endl;
        cout<<"Would you like to repeat this program? Y/N"<<endl;
        cin>>repeat;
    }while(repeat=='T'||repeat=='t');
        
                break;
            }

            default:{
                cout<<"Exit the Program"<<endl;
            }
        }
        
        
    }while(choice>='1'&&choice<='9');
    
   
    
    //Exit stage right!
    return 0;
}

