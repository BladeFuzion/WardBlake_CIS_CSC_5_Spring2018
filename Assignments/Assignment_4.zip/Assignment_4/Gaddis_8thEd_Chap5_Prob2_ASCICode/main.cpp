/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 28, 2018, 9:30 PM
 * Purpose:  Characters for the ASCII Codes
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Map inputs to outputs or process the data
    for (int i=0;i<=127;i++){
        cout<<static_cast<char>(i);
        if (i%16==15)cout<<endl;   //Every 16 symbols, end line
    }
    //Output the transformed data
    
    //Exit stage right!
    return 0;
}

