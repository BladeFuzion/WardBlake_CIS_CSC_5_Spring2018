/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on May 6, 2018, 7:20 PM
 * Purpose:  Menu for Assignment 5
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <cstdlib>   //Random Number Generator
#include <iomanip>   //Formatting
#include <cmath>     //Math Library
#include <string>
float cvs (int fahren);//function celsius

const int strtFah=0,//constants is taken from a previous assignment, modified it to use a function
          endFahr=20,
          incrmnt=1;
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants
const float GRAV=9.8f;

//Function Prototypes
void fallTim(float &time);
float fallDis(float);

void kin(float &mass, float &velo);
float kinEngy (float,float);

void average(float a,float b,float c,float d){
    cout<<"First score:"<<endl;
    cin>>a;
    cout<<"Second score: "<<endl;
    cin>>b;
    cout<<"Third score: "<<endl;
    cin>>c;
    cout<<"Fourth score: "<<endl;
    cin>>d;
    float ave = (a+b+c+d)/4;
    cout<<"The average is "<<ave<<endl;
    float temp= pow(a-ave,2)+pow(b-ave,2)+pow(c-ave,2)+pow(d-ave,2);
    float dev= temp/4;
    cout<<"The standard deviation is: "<<dev<<endl; 
}

void inputHr(int hours, int minutes);
void cnvrtHr(int hours, int AMPM);
void outptHr(int hours, int minutes, int AMPM);

void waitTme(int &Hour,int &Min,int wait){
    float addHr=Hour;
    float addMin=Min+(wait);
    if(addMin>=60)addHr=Hour+(Min+wait)/60;
    if(addMin>=60)addMin=(Min+wait)%60;
 
    cout<<"The wait time is over: "<<addHr<<":"<<addMin<<endl;
}

//calcRtl function prototype
float calcRtl (float cost, float markUp);//calcRtl function
                                         //arguments holds the floats: cost and markUp %

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    char choice;
    
    //Show menu and Loop
    do{
        //Display Menu
        cout<<"Type 0 to exit"<<endl;
        cout<<"Type 1 for Gaddis_10thEd_Chap6_Prob1_Markup"<<endl;
        cout<<"Type 2 for Gaddis_10thEd_Chap6_Prob2_Celsius"<<endl;
        cout<<"Type 3 for Gaddis_10thEd_Chap6_Prob3_falDist"<<endl;
        cout<<"Type 4 for Gaddis_10thEd_Chap6_Prob4_KinEngy"<<endl;
        cout<<"Type 5 for Savitch_10thEd_Chap5_PracProb1_Scores"<<endl;
        cout<<"Type 6 for Savitch_10thEd_Chap5_PracProb2_Lengths"<<endl;
        cout<<"Type 7 for Savitch_10thEd_Chap5_PracProb3_LengthsV2"<<endl;
        cout<<"Type 8 for Savitch_10thEd_Chap5_PracProb4_LengthsV3"<<endl;
        cout<<"Type 9 for Savitch_10thEd_Chap5_ProgProb1_Time"<<endl;
        
        //Input the choice
        cin>>choice;
        
        //Place solutions to problems in switch statement
        switch(choice){
            case '1':{
    float cost, markUp;//variables set to double data type
cout<<fixed<<showpoint<<setprecision(2);//setting decimal place to 2
cout<<"Enter the wholesale cost for the item: $";// user is asked to enter in the cost of an item
cin >>cost;

//validate the cost price
while(cost<0)//the cost must exceed 0 dollars
{
cout<<"Please enter a positive number. $"<<endl;
cin>>cost;
}
cout<<"Now please enter its markup percentage: ";//user is asked to enter in the markUp
cin>>markUp;

//validate the markup percentage
while(markUp<0)//the cost must exceed 0 %
{
cout<<"Please enter a positive number for markup: ";
cin>>markUp;
}

//convert markup percentage to two decimal point
markUp=(markUp/100);
cout<<"The retail price for the item is: "<<endl;
cout<<"$ "<<calcRtl(cost, markUp)<<endl;

                break;
            }
            case '2':{
float celcius; 
    cout<<fixed<<showpoint<<setprecision(2);
    
    for(int fahren=strtFah;fahren<=endFahr;fahren++)//fahrenheit conversion to celsius incremented by 20
    {
        celcius=cvs(fahren);
        cout<<fahren<<" Fahrenheit"<<" = "<<celcius<<" Celsius"<<endl;
    }

                break;
            }
            case '3':{
            //Declare Variables
    //Inputs
    float time,//Enter Time in Seconds
       total=0;//Total Fall Distance
    
    //Call Reference Function For Value of Seconds
    fallTim(time);
    
    //For Loop 10 times
    for(int arg=1;arg<=10;arg++)
    {
        //Call Function For Falling Distance
        total=fallDis(time);
        
        //Divide to Display 10 Distances
        total/=arg;
        
        //Display function Output of Falling Distance (meters)
        cout<<"Your Falling Distance Is: "<<total<<endl;
    }
                break;
            }
            case '4':{
//Declare Variables & Initialize Entries
    //Inputs
    float mass,         //Mass of Object (kilograms)
          velo,         //Velocity (meters per second)
        objMass;        //Calculated Kinetic Velocity 
    
    //Call Reference Function For values Mass & Velocity
    kin(mass,velo);
    
    //Call Kinetic Energy Function 
    objMass=kinEngy(mass,velo);
    
    //Display Kinetic Energy 
    cout<<"Kinetic Energy Produced Is: "<<objMass<<endl;

                break;
            }
            case '5':{
            char choose;
    int a,b,c,d;
    do{
        average( a,b,c,d);
        cout<<"again? [Y/N]"<<endl;
        cin>>choose;
    
    }while(choose=='y'||choose=='Y');
                break;
            }
            case '6':{
 //Declare Variables
 string answer;
 do { 
    float feet,inches,meters,cm; 
      cout<<"Feet: "; 
      cin>>feet; 
      cout<<"Inches: "; 
      cin>>inches;
   
      meters=(feet + inches/12)*0.3048;

      cm=modf(meters, &meters);
      cm*=100; 
      cout<<"There are "<<meters<<" meters, "<<cm<<" centimeters in " 
          <<feet<<" feet, "<<inches<<" inches"<<endl; 
    cout<<"Would you like to do another conversion? yes/no : "; 
    cin>>answer;
 } while (answer=="y"||answer=="Y"); 
                break;
            }
            case '7':{
        string answer;
 do { 
    float feet, inches, meters, cm; 
      cout<<"Meters: "; 
      cin>>meters; 
      cout<<"Centimeters: "; 
      cin>>cm;
 
      feet=(meters+cm/100)/0.3048; 
      inches=modf(feet,&feet); 
      inches*= 12;
 
      cout<<"There are "<<feet<<" feet, "<<inches<<" inches in " 
          <<meters<<" meters, "<<cm<<" centimeters"<<endl; 

    cout<<"Would you like to do another conversion? yes/no: "<<endl; 
    cin>>answer;
 } while(answer == "y"); 
                break;
            }
            case '8':{
             string answer;
 do { 
    int choice=0;
    cout<<"Select the type of conversion you would like to perform: "<<endl
        <<"1. Feet/inches to meters/centimeters"<<endl
        <<"2. Meters/centimeters to feet/inches"<<endl 
        <<"enter 1 or 2: ";
 
    cin>>choice;
 
    float feet,inches,meters,cm; 
    if(choice==1) { 
      cout<<"Feet: "; 
      cin>>feet; 
      cout<<"Inches: "; 
      cin>>inches; 
      
      meters=(feet+inches/12)*0.3048;
      cm=modf(meters,&meters);
      cm*=100; 
      cout<<"There are "<<meters<<" meters, "<<cm<<" centimeters in " 
          <<feet<<" feet, "<<inches<<" inches"<<endl; 
    }
    else if(choice==2) { 
      cout<<"Meters: "; 
      cin>>meters; 
      cout<<"Centimeters: "; 
      cin>>cm;

      feet=(meters+cm/100)/0.3048; 
      inches=modf(feet,&feet); 
      inches*=12;
 
      cout<<"There are "<<feet<<" feet, "<<inches<<" inches in " 
          <<meters<<" meters, "<<cm<<" centimeters"<<endl; 
    }

    cout<<"Would you like to do another conversion? y/n : "; 
    cin>>answer;
 } while(answer == "y"); 
                break;
            }
            case '9':{
            int hours, minutes, AMPM;
	char A, P;
        char answer;
        do{
	void inputHr(int hours, int minutes);
	{
	cout<<"Enter the number hours"<<endl;
	cin>>hours;
	cout<<"Enter the number minutes"<<endl;
	cin>>minutes;
	}
	void cnvrtHr(int hours, int AMPM);
	{
	if(hours<12)
	{
		hours=hours;
		minutes=minutes;
		AMPM='A';
	}
	if(hours>12)
	{
		hours=hours-12;
		minutes = minutes;
		AMPM='P';
	}
	}
	void outptHr(int hours, int minutes, int AMPM);
	{
	if(AMPM=='P')
	{
		cout<<"The time in 12 hour notation is "<<hours<<":"<<minutes<<" PM"<<endl;
	}
	if(AMPM=='A')
	{
		cout<<"The time in 12 hour notation is "<<hours<<":"<<minutes<<" AM"<<endl;
	}
	}
        cout<<"Would you like to repeat?"<<endl;
        cout<<"Please only enter 'y' or 'Y'"<<endl;
        cin>>answer;
        }while (answer=='y'||answer=='Y');
                break;
            }
            default:{
                cout<<"Exit the Program"<<endl;
            }
        }
        
    }while(choice>='1'&&choice<='9');
 
    //Exit stage right
    return 0;
}
float calcRtl(float cost, float markUp)//function of calcRtl
{
return(cost*markUp)+cost;//calculate retail price/markUP % and return value to main function
}

float cvs(int fahren)//function holds the fahrenheit variable. 
{
    return(static_cast<float>(fahren)-32)*5/9;//calculates the conversion between fahernheit
}

//Reference Function For Seconds of Fall Time
//&time= falling time in seconds
void fallTim(float &time)
{
    cout<<"Enter A Time (in Seconds) for Falling Distance Calculation: ";
    cin>>time;
}

//Function For Falling Distance
//Formula Equates Falling Distance (meters)
float fallDis(float time)
{
 //Return Falling Distance Formula
return .5f*GRAV*time*time;
   
}

//Reference Function For Mass & Velocity
//&mass = mass  &velo= velocity
void kin(float &mass, float &velo)
{
  //User Enter Mass of Object 
    cout<<"Enter Mass of Object: ";
    cin>>mass;
    
    //User Enter Velocity of Object 
    cout<<"Enter Velocity of Object: ";
    cin>>velo;  
}
//Kinetic Energy Function
//Formula Used to Equate Kinetin Energy
//massObj= mass of object    veloss= velocity
float kinEngy (float massObj ,float veloss){
    
    return 0.5f*massObj*veloss*veloss;


}