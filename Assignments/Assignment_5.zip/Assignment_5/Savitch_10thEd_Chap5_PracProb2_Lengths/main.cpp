/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on May 3, 2018, 7:00 PM
 * Purpose: converts from feet/inches to meters/centimeters 
 */
//System Libraries
#include <iostream>
#include <cmath>
#include <string> 
using namespace std;

//Execution Begins Here
int main(int argc, char** argv){
    //Declare Variables
 string answer;
 do { 
    float feet,inches,meters,cm; 
      cout<<"Feet: "; 
      cin>>feet; 
      cout<<"Inches: "; 
      cin>>inches;
   
      meters=(feet + inches/12)*0.3048;

      cm=modf(meters, &meters);
      cm*=100; 
      cout<<"There are "<<meters<<" meters, "<<cm<<" centimeters in " 
          <<feet<<" feet, "<<inches<<" inches"<<endl; 
    cout<<"Would you like to do another conversion? yes/no : "; 
    cin>>answer;
 } while (answer=="y"||answer=="Y"); 

return 0;
//Exit Stage
}

