/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on May 3, 2018, 4:30 PM
 * Purpose: Celsius Temperature Table 
 */
#include <iostream>
#include <iomanip>
float cvs (int fahren);//function celsius

const int strtFah=0,//constants is taken from a previous assignment, modified it to use a function
          endFahr=20,
          incrmnt=1;

using namespace std;

//User Libraries

//Global Constants

//Function Prototype

//Execution starts here!

int main(int argc, char** argv) {
    
    float celcius; 
    cout<<fixed<<showpoint<<setprecision(2);
    
    for(int fahren=strtFah;fahren<=endFahr;fahren++)//fahrenheit conversion to celsius incremented by 20
    {
        celcius=cvs(fahren);
        cout<<fahren<<" Fahrenheit"<<" = "<<celcius<<" Celsius"<<endl;
    }

    //exit stage right
    return 0;
}

float cvs(int fahren)//function holds the fahrenheit variable. 
{
    return(static_cast<float>(fahren)-32)*5/9;//calculates the conversion between fahernheit
}
