/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on May 5, 2018, 12:30 PM
 * Purpose:  Kinetic Energy 
 */

//System Libraries
#include <iostream>
#include<cstdlib>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes
void kin(float &mass, float &velo);
float kinEngy (float,float);

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables & Initialize Entries
    //Inputs
    float mass,         //Mass of Object (kilograms)
          velo,         //Velocity (meters per second)
        objMass;        //Calculated Kinetic Velocity 
    
    //Call Reference Function For values Mass & Velocity
    kin(mass,velo);
    
    //Call Kinetic Energy Function 
    objMass=kinEngy(mass,velo);
    
    //Display Kinetic Energy 
    cout<<"Kinetic Energy Produced Is: "<<objMass<<endl;

    return 0;
}
//Reference Function For Mass & Velocity
//&mass = mass  &velo= velocity
void kin(float &mass, float &velo)
{
  //User Enter Mass of Object 
    cout<<"Enter Mass of Object: ";
    cin>>mass;
    
    //User Enter Velocity of Object 
    cout<<"Enter Velocity of Object: ";
    cin>>velo;  
}
//Kinetic Energy Function
//Formula Used to Equate Kinetin Energy
//massObj= mass of object    veloss= velocity
float kinEngy (float massObj ,float veloss){
    
    return 0.5f*massObj*veloss*veloss;


}