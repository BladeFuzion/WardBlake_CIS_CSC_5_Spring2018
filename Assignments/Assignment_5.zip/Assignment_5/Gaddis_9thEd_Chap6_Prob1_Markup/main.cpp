/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on May 4, 2018, 1:30 PM
 * Purpose: Gaddis_10thEd_Chap6_Prob1_Markup
 */
#include <iostream>
#include <iomanip> //setprecision
using namespace std;

//User Libraries

//Global Constants

//Function Prototype

//Execution starts here

//calcRtl function prototype
float calcRtl (float cost, float markUp);//calcRtl function
                                         //arguments holds the floats: cost and markUp %

int main(int argc, char** argv) {
    
float cost, markUp;//variables
cout<<fixed<<showpoint<<setprecision(2);//setting decimal place to 2
cout<<"Enter the wholesale cost for the item: $";// user is asked to enter in the cost of an item
cin >>cost;

//validate the cost price
while(cost<0)//the cost must exceed 0 dollars
{
cout<<"Please enter a positive number. $"<<endl;
cin>>cost;
}
cout<<"Now please enter its markup percentage: ";//user is asked to enter in the markUp
cin>>markUp;

//validate the markup percentage
while(markUp<0)//the cost must exceed 0 %
{
cout<<"Please enter a positive number for markup: ";
cin>>markUp;
}

//convert markup percentage to two decimal point
markUp=(markUp/100);
cout<<"The retail price for the item is: "<<endl;
cout<<"$ "<<calcRtl(cost, markUp)<<endl;

//exit stage right
return 0;
}

float calcRtl(float cost, float markUp)//function of calcRtl
{
return(cost*markUp)+cost;//calculate retail price/markUP % and return value to main function
}



