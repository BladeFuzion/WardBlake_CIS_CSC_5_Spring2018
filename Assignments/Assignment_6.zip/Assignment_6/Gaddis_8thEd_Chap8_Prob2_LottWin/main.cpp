/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on May 26, 2018, 5:00 PM
 * Purpose: Gaddis_8thEd_Chap8_Prob2_LottWin
 */

//User Libraries
#include <iostream>
#include <cstdlib>

using namespace std;

//User Libraries

//Global Constant

//Function Prototype

//Execution starts here!

const int LCKYNUM =10; //"lucky" combinations as given by book
// Function prototype that searches winning ticket number, linear search method
int tktSrch(const int [], int, int);

int main(int argc, char** argv)
{
	//user continues playing the lottery
	char again;

	const char QUIT = 'N';
	//determines if player's ticket is a winner
	int winNum;
	//5 digit "lucky" ticket number entered by user
	int lckyNum;
	//holds winning ticket number
	int ticket;

	//Array holding the winning tickets for each week
	int lotoNum[LCKYNUM] = {13579, 26791, 26792, 33445, 55555,
	62483, 77777, 79422, 85647, 93121};	
	//Player decides if they want to continue playing

			for (int week = 0; week < 10; week++)
			{
				//Winning lotto ticket for each week (10 weeks total)
				ticket = lotoNum[week];
				
				cout << "Please enter your 'lucky' combination; " << (week + 1) << ": " << endl;
				//Player's ticket number
				cin >> lckyNum;
				//Calls linear search for winning lotto ticket
				winNum = tktSrch(lotoNum, LCKYNUM, lckyNum); 
				//Error message if user's "lucky" number is not the winning ticket
				if ((winNum == -1) || lckyNum != ticket)
				{
				
					cout << "Sorry, you did not win. ";
					cout << "Try Again?? (Y/N)";
					cin >> again;
				}
				
				//Player wins the lottery
				else if (lckyNum == ticket)
				{
		
					
					cout << "CONGRATULATIONS! YOU WON THE LOTTERY!";
					cout << "Play again? (Y/N)";
					cin >> again;
				}
				
				if ((again != 'Y') && (again != 'y')) 
					{
						//exit message
						cout << "Have a great day!";
						//exits the lottery program
						exit(0);
					}
	
                        }
	//Exit stage right
        return 0;
}

//linear search method, to search for the winning lottery numbers
int tktSrch(const int tktList[], int numTkts, int winNum)
{
	int index = 0;
	int psition = -1;
	bool found = false;

	while ((index < numTkts) && !found) 
	{
		if (tktList[index] == winNum)
		{
			found = true;
			psition = index;
		}
		index ++;
	}
	return psition;
}

