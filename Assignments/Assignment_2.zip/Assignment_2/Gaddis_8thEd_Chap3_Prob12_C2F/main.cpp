/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 8, 2018, 11:50 AM
 * Purpose:  Write a program that converts 
 *           Celsius temperatures to Fahrenheit 
 *           temperatures.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
float celsius;

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    cout<<"This program will convert Celsius temperatures \n"<<
          "to Fahrenheit temperatures."<<endl;
    cout<<"Type in Celsius Temperature."<<endl;
    cin>>celsius;
    float Fahren=((9*celsius)/5)+32;
    cout<<"If it is "<<celsius<<" degrees in Celsius."<<endl;
    cout<<"Then it would be "<<Fahren<<" degrees in Fahrenheit."<<endl;
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    
    //Exit stage right!
    return 0;
}