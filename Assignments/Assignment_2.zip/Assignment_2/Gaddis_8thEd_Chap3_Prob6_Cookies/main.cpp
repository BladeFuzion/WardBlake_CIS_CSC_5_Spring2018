/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 10, 2018, 12:05 PM
 * Purpose:  A cookie recipe calls for the following ingredients:
                • 1.5 cups of sugar
                • 1 cup of butter
                • 2.75 cups of flour
 *          Write a program that asks the user how many cookies 
 *          he or she wants to make, and then displays the number 
 *          of cups of each  ingredient needed for the specified 
 *          number of cookies.
 */

//System Libraries
#include <iostream>//I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries
float   cupOsug=1.5, //Original cups of sugar
        cupObut=1,   //Original cups of butter
        cupOflr=2.75,//Original cups of flour
        cookies=48,  //Original amount of cookies
        amount,      //Amount you wish to make
        sugAmnt,     //Amount of sugar for 1 cookie
        butAmnt,     //Amount of butter for 1 cookie
        flrAmnt,     //Amount of flour for 1 cookie
        sugar,       //New amount of sugar
        butter,      //New amount of butter
        flour;       //New amount of flour

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
        sugAmnt=cupOsug/cookies;
        butAmnt=cupObut/cookies;
        flrAmnt=cupOflr/cookies;
        
    //Initial Variables
    
    //Map/Process Inputs to Outputs

    //Display Outputs
        cout<<"This program will tell you the amount \n"
              "of ingredients you need to make cookies.\n"<<endl;
        cout<<"Put in the amount of cookies you wish to make."<<endl;
        cin>>amount;
        cout<<endl;
            sugar=sugAmnt*amount;
            butter=butAmnt*amount;
            flour=flrAmnt*amount;
        cout<<"You will need a total of \n"<<sugar<<" cups of sugar, "<<endl;
        cout<<butter<<" cups of butter, and "<<endl;
        cout<<flour<<
              " cups of flour to make "<<amount<<" cookies.\n";

    //Exit program!
    return 0;
}