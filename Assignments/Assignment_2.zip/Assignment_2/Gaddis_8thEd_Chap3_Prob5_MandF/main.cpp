/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 11, 2018, 4:10 PM
 * Purpose:  Write a program that asks the user for
 *  the number of males and the number of females
 *  registered in a class. The program should display
 *  the percentage of males and females in the class.
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

//User Libraries
int     male,
        female;
        

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout<<"This program will calculate the percentage\n"
        <<"of males and females registered for the class.\n"<<endl;
    cout<<"Type in how many Males are registered."<<endl;
    cin>>male;
    cout<<"Type in how many Females are registered."<<endl;
    cin>>female;
    float total=male+female,
          prcMale=(male/total)*100,
          prcFeml=(female/total)*100;
    cout<<endl;
    cout<<setprecision(4)<<prcMale<<"% of Males and "<<endl;
    cout<<setprecision(4)<<prcFeml<<"% of Females are registered for class."<<endl;
    
    //Exit stage right!
    return 0;
}