/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 12, 2018, 1:20 PM
 * Purpose:  Write a program that plays 
 *           a word game with the user.
 */

//System Libraries
#include <iostream>
#include <string>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    string name, 
            age,
            city,
            college,
            prfsion,
            animal,
            petname;
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout<<"Type in his or her first name. "<<endl;
    cin>>name;
    cout<<"Type in his or her age. "<<endl;
    cin>>age;
    cout<<"Type in the name of a city. "<<endl;
    cin>>city;
    cout<<"Type in the name of a college (Only the initials). "<<endl;
    cin>>college;
    cout<<"Type in a profession. "<<endl;
    cin>>prfsion;
    cout<<"Type in a type of animal. "<<endl;
    cin>>animal;
    cout<<"Type in a pet's name. "<<endl;
    cin>>petname;
    cout<<endl;
    cout<<"There once was a person named "<<name<<" who lived in \n"
        <<city<<". At the age of "<<age<<", "<<name<<" went to a college at \n"
        <<college<<". "<<name<<" graduated and went to work as a \n"
        <<prfsion<<". Then, "<<name<<" adopted a(n) "<<animal<<" named \n"
        <<petname<<". They both lived happily ever after!"<<endl;   
    
    //Exit stage right!
    return 0;
}