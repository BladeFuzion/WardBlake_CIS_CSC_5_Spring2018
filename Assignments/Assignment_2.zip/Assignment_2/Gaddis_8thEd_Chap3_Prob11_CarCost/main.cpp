/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 13, 2018, 6:45 PM
 * Purpose:  Write a program that asks the user to 
 *      enter the monthly costs for the following
 *      expenses incurred from operating his or her 
 *      automobile: loan payment, insurance, gas,
 *      oil, tires, and maintenance.
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries
float loanPay,  //loan payments
       insarnc, //insurance
        gas,    //gas
        oil,    //oil
        tires,  //tires
        maintnc;//maintenance
        
//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout<<"This program will help you find out your\n"<<
          "monthly and yearly automobile costs.\n"<<endl;
    cout<<"Type in your loan payment."<<endl;
    cin>>loanPay;
    cout<<"Type in your insurance payment."<<endl;
    cin>>insarnc;
    cout<<"Type in your gas costs."<<endl;
    cin>>gas;
    cout<<"Type in your oil costs."<<endl;
    cin>>oil;
    cout<<"Type in your tire costs."<<endl;
    cin>>tires;
    cout<<"Type in your maintenance costs."<<endl;
    cin>>maintnc;
    cout<<endl;
    float   monthly = loanPay+insarnc+gas+oil+tires+maintnc, //monthly payments
            annualy= monthly * 12;                           //annual payments
    cout<<setprecision(6)<<"Your monthly costs will be a total of $"<<monthly<<"."<<endl;
    cout<<setprecision(6)<<"Your annual costs will be a total of $"<<annualy<<"."<<endl;
    
    
    //Exit stage right!
    return 0;
}