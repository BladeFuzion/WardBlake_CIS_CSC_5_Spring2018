/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 12, 2018, 2:30 PM
 * Purpose:  Write a program that asks for five test scores. 
 *           The program should calculate the average test 
 *           score and display it. The number displayed 
 *           should be formatted in fixed-point
             notation, with one decimal point of precision.
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    float   test1=0.0,
            test2=0.0,
            test3=0.0,
            test4=0.0,
            test5=0.0,
            average;
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout<<"This program will calculate the average\n"<<
          "test scores of five tests.\n"<<endl;
    cout<<"Type in test 1's score: "<<endl;
    cin>>test1;
    cout<<"Type in test 2's score: "<<endl;
    cin>>test2;
    cout<<"Type in test 3's score: "<<endl;
    cin>>test3;
     cout<<"Type in test 4's score: "<<endl;
    cin>>test4;
     cout<<"Type in test 5's score: "<<endl;
    cin>>test5;
    cout<<endl;
    average=(test1+test2+test3+test4+test5)/5;
    cout<<fixed<<setprecision(1)<<"The test score average is "
               <<average<<" points. "<<endl;
    
    //Exit stage right!
    return 0;
}