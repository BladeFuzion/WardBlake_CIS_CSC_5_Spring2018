/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 22, 2018, 4:10 PM
 * Purpose:  Color Mixer.
 */

//System Libraries
#include <iostream>
#include <string>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
	string  primry1,
                primry2,
                error;
               
        
    //Initialize Variables
    
    //Process/Map inputs to outputs
    cout<<"There are three primary colors: blue, yellow and red. "<<endl;
    cout<<"Pick two primary colors to see what new color is made: "<<endl;
    
    //Output data
    cout<<"Primary color one: ";
    cin>>primry1;
    cout<<endl;
    cout<<"Primary color two: ";
    cin>>primry2;
    cout<<endl;

    if (primry1=="blue" and primry2=="red"){
        cout<<"When you mix red and blue, you get purple. ";
    }
    else if (primry1=="red" and primry2=="blue"){
        cout<<"When you mix red and blue, you get purple. ";
    }
    else if (primry1=="red" and primry2=="yellow"){
        cout<<"When you mix red and yellow, you get orange. ";
    }
    else if (primry1=="yellow" and primry2=="red"){
        cout<<"When you mix red and yellow, you get orange. ";
    }
    else if (primry1=="blue" and primry2=="yellow"){
        cout<<"When you mix blue and yellow, you get green. ";
    }
    else if (primry1=="yellow" and primry2=="blue"){
        cout<<"When you mix blue and yellow, you get green. ";
    }
    else if (primry1!=error and primry2!=error){
        cout<<"Something is misspelled. ";
    }
    //Exit stage right!
    return 0;
}