/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 21, 2018, 8:00 PM
 * Purpose:  Math Tutor 2
 */

//System Libraries
#include <iostream>
#include <cstdlib> //Randum number library
#include <ctime>   //namespace I/O stream library created
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    unsigned short op1,op2,stuAns,correct,wrong;
    
    //Initialize Variables
    op1=rand()%900+100;//[100,999]
    op2=rand()%999+1;  //[1,999]
    cout<<"This is a simple Math Tutor Program"<<endl;
    cout<<"Input the Answer to the following addition problem"<<endl;
    cout<<setw(5)<<op1<<endl;
    cout<<"+ "<<setw(3)<<op2<<endl;
    cout<<"-----"<<endl;
    
    //calculate the answer
    correct=op1+op2;
    wrong=op1+op2!=stuAns;
    cout<<((correct>10000)?" ":"  ");
    cin>>stuAns;
    //Output data
    cout<<endl<<(stuAns==correct?"Correct Answer.":"Wrong Answer.")<<endl;
    if (stuAns!=correct){
        cout<<"The correct answer is "<<correct<<"."<<endl;
    }
    else if(stuAns=correct){
        cout<<"Congratulations! You are correct!"<<endl;
    }
    //Exit stage right!
    return 0;
}