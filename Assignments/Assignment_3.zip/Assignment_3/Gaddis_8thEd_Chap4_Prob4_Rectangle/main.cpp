/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 19, 2018, 6:40 PM
 * Purpose:  The area of a rectangle is the rectangle’s length times its width.
 *           Write a program that asks for the length and width of two 
 *           rectangles. The program should tell the user which
 *           rectangle has the greater area, or if the areas are the same.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
float   length1, //Length on rectangle 1
        length2, //Length on rectangle 2
        width1,  //Width on rectangle 1
        width2,  //Width on rectangle 2
        area1,   //Area on rectangle 1
        area2;   //Area on rectangle 2

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout<<"This program will tell you which of two \n"
        <<"rectangles has the greater area, or if the \n"
        <<"areas are the same.\n"<<endl;
    cout<<"Type in the length of your first rectangle. "<<endl;
    cin>>length1;
    cout<<"Type in the width of your first rectangle. "<<endl;
    cin>>width1;
    cout<<"Type in the length of your second rectangle. "<<endl;
    cin>>length2;
    cout<<"Type in the width of your second rectangle. "<<endl;
    cin>>width2;
    cout<<endl;
    area1=width1*length1;
    area2=width2*length2;
    cout<<"Rectangle 1 has an area of: "<<area1<<endl;
    cout<<"Rectangle 2 has an area of: "<<area2<<endl;
    cout<<endl;
    
    if (area1>area2){
        cout<<"Your first rectangle has the greater area. "<<endl;
    }
    else if (area1<area2){
        cout<<"Your second rectangle has the greater area. "<<endl;
    }
    else if (area1=area2){
        cout<<"Both of your rectangles have the same area."<<endl;
    }
    //Exit stage right!
    return 0;
}