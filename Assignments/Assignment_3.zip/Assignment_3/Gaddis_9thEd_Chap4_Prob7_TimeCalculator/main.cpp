/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 20, 2018, 7:50 PM
 * Purpose:  Time Calculator 
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

//User Libraries
int numOsec;

        
        
//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    cout<<"This is a Time Calculator.\n"<<endl;
    cout<<"Type in number of seconds: ";
    cin>>numOsec;
    cout<<endl;
int day=(numOsec/86400);
        cout<<"Day: "<<day<<endl;
int hours=((numOsec%86400)/3600);
        cout<<"Hours: "<<hours<<endl;
int minutes=(((numOsec%86400)%3600)/60);
        cout<<"Minutes: "<<minutes<<endl;
int seconds=(((numOsec%86400)%3600)%60);
        cout<<"Seconds: "<<seconds;
  
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    
    //Exit stage right!
    return 0;
}