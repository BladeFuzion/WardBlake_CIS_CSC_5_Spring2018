/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 22, 2018, 11:20 AM
 * Purpose:  Create a change -counting game that asks the 
 *           user to enter what coins to use to make
 *           exactly one dollar. 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
float   pennies=0.01,//How much a penny is worth
        peniAmt,     //How many pennies you have
        nickels=0.05,//How much a nickel is worth
        nickAmt,     //How many nickels you have
        dimes=0.10,  //How much a dime is worth
        dimeAmt,     //How many dimes you have
        qurters=0.25,//How much a quarter is worth
        quarAmt,     //How many quarters you have
        dollar=1;    //How much a dollar is worth

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    
    
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout<<"Welcome to the dollar Game!"<<endl;
    cout<<"Type in the amount of pennies you have."<<endl;
    cin>>peniAmt;
    float penittl=pennies*peniAmt;//Penny total
    cout<<endl;
    cout<<"Type in the amount of nickels you have."<<endl;
    cin>>nickAmt;                 
    float nickttl=nickels*nickAmt;//Nickel total
    cout<<endl;
    cout<<"Type in the amount of dimes you have."<<endl;
    cin>>dimeAmt; 
    float dimettl=dimes*dimeAmt;  //Dime total
    cout<<endl;
    cout<<"Type in the amount of quarters you have."<<endl;
    cin>>quarAmt;
    float quarttl=qurters*quarAmt;//Quarter total
    cout<<endl;
    if (quarttl+dimettl+nickttl+penittl==dollar){
        cout<<"You win! You have exactly 1 dollar!"<<endl;
    }
    else if (quarttl+dimettl+nickttl+penittl!=dollar){
        cout<<"You lose.\n"<<"You have a total of ";
        float total=quarttl+dimettl+nickttl+penittl;//Total amount of money
        cout<<"$"<<total<<"."<<endl;
    }

    //Exit stage right!
    return 0;
}