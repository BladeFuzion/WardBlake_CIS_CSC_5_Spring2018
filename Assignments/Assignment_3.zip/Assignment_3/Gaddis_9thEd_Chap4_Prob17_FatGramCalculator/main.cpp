/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 22, 2018, 2:30 PM
 * Purpose:  Write a program that asks for the number of calories 
 *           and fat grams in a food. The program should display 
 *           the percentage of calories that come from fat.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
float   calries,//calories
        ftGrams;//fat grams

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    cout<<"This program is a Fat Gram Calculator.\n"<<endl;
    cout<<"Type in the amount of calories. "<<endl;
    cin>>calries;
    cout<<"Type in the amount of fat grams. "<<endl;
    cin>>ftGrams;
    float calFfat=ftGrams*9;            //Calories from fat
    cout<<"You have "<<calFfat<<" calories from fat."<<endl;
    float percntg=(calFfat/calries)*100;//Percentage of Calories from fat
    cout<<"You have "<<percntg<<"% of calories from fat."<<endl;
    if (percntg<30){
        cout<<"Your food is low in fat."<<endl;
    }
   
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    
    //Exit stage right!
    return 0;
}