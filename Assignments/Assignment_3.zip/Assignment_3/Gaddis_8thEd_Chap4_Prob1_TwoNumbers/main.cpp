/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 21, 2018, 7:00 PM
 * Purpose:  Create a CSC/CIS 5 Template
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
int number1,number2;

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    cout<<"This program will calculate which numbers are greater and lower."<<endl;
    cout<<"Type in your first number."<<endl;
    cin>>number1;
    cout<<"Type in your second number."<<endl;
    cin>>number2;
    if (number1>number2){
        cout<<number1<<" is the bigger number.\n"
            <<number2<<" is the lower number."<<endl;
    }else if(number1<number2){
        cout<<endl;
        cout<<number2<<" is the bigger number.\n"
            <<number1<<" is the lower number."<<endl;
    }
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    
    //Exit stage right!
    return 0;
}