/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 3, 2018, 12:05 PM
 * Purpose:  Write a C++ program that 
 *           reads in two integers and then 
 *           outputs both their sum and their
 *           product.
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Initial Variables
        int ClsRoom, Studnts, TotStud;
        //Classrooms, Students, Total Students
    
    //Map/Process Inputs to Outputs

    //Display Outputs
    
    
    cout<<"Type in number of student(s) that can "
          "fit in each classroom:\n";
    cin>>Studnts;
    cout<<endl;
    cout<<"Now type in the total amount of "
          "classroom(s) the school has:\n";
    cin>>ClsRoom;
    cout<<endl;
    cout<<"If a total of "<<Studnts<<
          " student(s) can fit in each classroom\n"
        <<"and there is a total of "<<ClsRoom<<" classroom(s) "
            "within the school\n";
    TotStud = Studnts * ClsRoom;
    cout<<"then that means you can fit a total of "<<TotStud
        <<" student(s) within the school.\n"<<endl;
    cout<<"The Program is now complete.\n";
    //Exit program!
    return 0;
}