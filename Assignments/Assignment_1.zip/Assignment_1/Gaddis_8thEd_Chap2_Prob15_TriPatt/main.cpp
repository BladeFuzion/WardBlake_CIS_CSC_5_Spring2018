/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 2, 2018, 12:05 PM
 * Purpose:  Writing a program that
 *           displays a triangle pattern.
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables

    //Initial Variables
    
    //Map/Process Inputs to Outputs

    //Display Outputs
    cout<<"   *\n"
        <<"  ***\n"
        <<" ******\n"
        <<"********\n"
        <<"\n"
        <<"Program is now completed.\n";
        
    //Exit program!
    return 0;
}