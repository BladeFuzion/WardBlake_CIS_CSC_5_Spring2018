/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 2, 2018, 12:20 PM
 * Purpose:  Write a program that stores the integers 
 *           50 and 100 in variables, and stores the sum of
             these two in a variable named total. Im going 
 *           to change the variables to sunflower seeds.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
   int var1 = 50;//First bag of sunflower seeds
   int var2 = 100;//Second bag of sunflower seeds
   int total = var1 + var2;//Total of both bags combined
   
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    cout<<" The first bag of sunflower seeds contains "<<var1<<" seeds. \n"
    <<" The second bag of sunflower seeds contains "<<var2<<" seeds.\n"
    <<" The total of both bags combined would contain "
    <<total<<" seeds."<<endl;
    
    //Exit stage right!
    return 0;
}