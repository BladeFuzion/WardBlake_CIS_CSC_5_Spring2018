/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 2, 2018, 12:05 PM
 * Purpose:  A customer in a store is purchasing 
 *           five items. The prices of the five 
 *           items are
             Price of item 1 = $15.95
             Price of item 2 = $24.95
             Price of item 3 = $6.95
             Price of item 4 = $12.95
             Price of item 5 = $3.95
 *           Write a program that holds 
 *           the prices of the five items 
 *           in five variables. 
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Initial Variables    
    float items1,
          items2,
          items3,  
          item1 = 15.95,
          item2 = 24.95,
          item3 = 6.95,
          item4 = 12.95,
          item5 = 3.95;
          
    items1 = item1+item2+item3+item4+item5;
    items2 = ((item1+item2+item3+item4+item5)*0.07);
    items3 = items1+items2;
    //Map/Process Inputs to Outputs

    //Display Outputs
            cout<<"All five items added together being \n"
                <<"$"<<items1
                <<", including a sales tax of 7%,\n"
                <<"adds up to a total of $"
                <<items3<<"."<<endl;
    //Exit program!
    return 0;
}