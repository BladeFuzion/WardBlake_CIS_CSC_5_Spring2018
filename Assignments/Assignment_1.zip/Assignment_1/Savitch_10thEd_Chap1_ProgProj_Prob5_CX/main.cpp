/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 2, 2018, 12:05 PM
 * Purpose:  Write a program that inputs
 *           a character from the keyboard 
 *           and then outputs a large block 
 *           letter "C" composed of that character.
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    char letter;
    //Initial Variables
    
    //Map/Process Inputs to Outputs

    //Display Outputs
    cout<<"Type in a character.\n";
    cin >>letter;
    cout<<"\n"
        <<"   "<<letter<<" "   <<letter<<" "<<letter<<endl
        <<"  " <<letter<<"    "<<letter<<endl
        <<" "  <<letter<<endl
        <<" "  <<letter<<endl
        <<" "  <<letter<<endl
        <<" "  <<letter<<endl    
        <<" "  <<letter<<endl
        <<"  " <<letter<<"    "<<letter<<endl
        <<"   "<<letter<<" "   <<letter<<" "<<letter<<endl<<"\n"
        <<"Program is now completed."<<endl;
            
    //Exit program!
    return 0;
}