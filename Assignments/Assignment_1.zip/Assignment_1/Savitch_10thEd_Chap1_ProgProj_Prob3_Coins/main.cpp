/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 2, 2018, 12:05 PM
 * Purpose:  Write a program that allows
 *           the user to enter a number of 
 *           quarters, dimes, and nickels
 *           and then outputs the monetary
 *           value of the coins in cents.
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    int quartrs, qurtAmt, dimes, dimeAmt, nickels, nickAmt;
    //Initial Variables
    quartrs = 25;
    dimes = 10;
    nickels = 5;        
    //Map/Process Inputs to Outputs

    //Display Outputs
    cout<<"Type in how many quarters you have. \n";
    cin>>qurtAmt;
    qurtAmt = quartrs * qurtAmt;
    cout<<"\n"
        <<"Now type in the amount of dimes you have. \n";
    cin>>dimeAmt;
    dimeAmt = dimes * dimeAmt;
    cout<<"\n"
        <<"Now type in the amount of nickels you have. \n";
    cin>>nickAmt;
    nickAmt = nickels * nickAmt;
    cout<<"\n"
        <<"You have a total of "<<qurtAmt + dimeAmt + nickAmt
        <<" cents.\n"
        <<"\n"
        <<"Program is now completed."<<endl;   
    
    //Exit program!
    return 0;
}