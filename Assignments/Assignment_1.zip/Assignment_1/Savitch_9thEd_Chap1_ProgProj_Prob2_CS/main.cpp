/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 2, 2018, 1:20 PM
 * Purpose:  Write a program that prints out "C S !"
 *           in large block letters.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants - Math/Physics Constants, Conversions,
//                   2-D Array Dimensions

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare Variables
    cout<<"**************************************************\n"
    <<"           "<<"C C C"<<"           S S S S"<<"        !!\n"
    <<"         "<<"C"<<"     "<<"  C    "<<"   "<<"S"<<"        "<<" S"
    <<"      !!\n"
    <<"        "<<"C"<<"             "<<"  "<<"S"<<"         "
    <<"        !!\n"
    <<"       "<<"C"<<"              "<<"   "<<"S "
    <<"               !!\n"
    <<"       "<<"C"<<"                   "<<"S S S S"
    <<"        !!\n"
    <<"       "<<"C"<<"                          "<<" S"
    <<"      !!\n"
    <<"        "<<"C"<<"                          "<<" S"
    <<"     !!\n"
    <<"         "<<"C"<<"     "<<"  C    "<<"   S        "<<" S\n"
    <<"           "<<"C C C"<<"           S S S S"<<"        00\n"
    <<"**************************************************\n"
    <<"     Computer Science is Cool Stuff!!!\n";
    
            
    //Initialize Variables
    
    //Process/Map inputs to outputs
    
    //Output data
    
    //Exit stage right!
    return 0;
}