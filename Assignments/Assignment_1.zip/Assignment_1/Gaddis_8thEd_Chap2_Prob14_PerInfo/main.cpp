/* 
 * File:   main.cpp
 * Author: Blake Ward
 * Created on March 2, 2018, 12:05 PM
 * Purpose:  Write a program that displays the 
 *           following pieces of information, 
 *           each on a separate line. Use only 
 *           a single cout statement to display 
 *           all of this information. 
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables

    //Initial Variables
    
    //Map/Process Inputs to Outputs

    //Display Outputs
        cout<<"Blake Ward.\n"
            <<"17790 Brazier Dr., Riverside, California, 92508.\n"
            <<"951-858-6164.\n"
            <<"Computer Science.\n";
    //Exit program!
    return 0;
}